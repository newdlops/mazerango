from django.apps import AppConfig


class MazerangoNewdlopsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mazerango_newdlops'
